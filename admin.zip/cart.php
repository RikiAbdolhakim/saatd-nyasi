<?php
session_start();

// Sahte ürün verisi
$products = [
    1 => [
        'name' => 'Casio G-Shock',
        'price' => 1500,
        'image' => 'assets/watch1.jpg'
    ],
    2 => [
        'name' => 'Rolex Submariner',
        'price' => 35000,
        'image' => 'assets/watch2.jpg'
    ],
    3 => [
        'name' => 'Fossil Chronograph',
        'price' => 3200,
        'image' => 'assets/watch3.jpg'
    ]
];

// Ürün sepete eklendiyse
if (isset($_GET['add'])) {
    $id = $_GET['add'];
    if (!isset($_SESSION['cart'][$id])) {
        $_SESSION['cart'][$id] = 1;
    } else {
        $_SESSION['cart'][$id]++;
    }
    header("Location: cart.php");
    exit;
}

// Sepetten ürün silme
if (isset($_GET['remove'])) {
    $id = $_GET['remove'];
    unset($_SESSION['cart'][$id]);
    header("Location: cart.php");
    exit;
}

$cart = isset($_SESSION['cart']) ? $_SESSION['cart'] : [];
$total = 0;
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <title>Sepetim - Saat Dünyası</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header>
        <div class="container">
            <h1>Saat Dünyası</h1>
            <nav>
                <a href="index.php">Anasayfa</a>
                <a href="products.php">Ürünler</a>
                <a href="cart.php">Sepetim</a>
                <a href="login.php">Giriş</a>
                <a href="register.php">Kayıt Ol</a>
            </nav>
        </div>
    </header>

    <section class="container">
        <h2>Sepetim</h2>
        <?php if (empty($cart)): ?>
            <p>Sepetiniz boş.</p>
        <?php else: ?>
            <table class="cart-table">
                <tr>
                    <th>Ürün</th>
                    <th>Adet</th>
                    <th>Fiyat</th>
                    <th>Toplam</th>
                    <th>İşlem</th>
                </tr>
                <?php foreach ($cart as $id => $quantity): 
                    $product = $products[$id];
                    $subtotal = $product['price'] * $quantity;
                    $total += $subtotal;
                ?>
                    <tr>
                        <td>
                            <img src="<?= $product['image'] ?>" width="60" style="vertical-align: middle;">
                            <?= $product['name'] ?>
                        </td>
                        <td><?= $quantity ?></td>
                        <td>₺<?= number_format($product['price'], 2, ',', '.') ?></td>
                        <td>₺<?= number_format($subtotal, 2, ',', '.') ?></td>
                        <td><a href="cart.php?remove=<?= $id ?>" class="btn">Sil</a></td>
                    </tr>
                <?php endforeach; ?>
                <tr>
                    <td colspan="3" style="text-align: right;"><strong>Genel Toplam:</strong></td>
                    <td colspan="2"><strong>₺<?= number_format($total, 2, ',', '.') ?></strong></td>
                </tr>
            </table>
        <?php endif; ?>
    </section>

    <footer>
        <div class="container">
            <p>&copy; 2025 Saat Dünyası | Tüm hakları saklıdır.</p>
        </div>
    </footer>
</body>
</html>
