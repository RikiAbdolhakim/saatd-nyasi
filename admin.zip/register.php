<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <title>Kayıt Ol - Saat Dünyası</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header>
        <div class="container">
            <h1>Saat Dünyası</h1>
            <nav>
                <a href="index.php">Anasayfa</a>
                <a href="products.php">Ürünler</a>
                <a href="cart.php">Sepetim</a>
                <a href="login.php">Giriş</a>
                <a href="register.php">Kayıt Ol</a>
            </nav>
        </div>
    </header>

    <section class="container">
        <h2>Kayıt Ol</h2>
        <form action="register.php" method="post" class="form-box">
            <label for="name">Ad Soyad:</label>
            <input type="text" name="name" required>

            <label for="email">E-posta:</label>
            <input type="email" name="email" required>

            <label for="password">Şifre:</label>
            <input type="password" name="password" required>

            <button type="submit" class="btn">Kayıt Ol</button>
        </form>
        <p>Zaten hesabınız var mı? <a href="login.php">Giriş yapın</a></p>
    </section>

    <footer>
        <div class="container">
            <p>&copy; 2025 Saat Dünyası | Tüm hakları saklıdır.</p>
        </div>
    </footer>
</body>
</html>



<?php
// Veritabanı bağlantısı
$host = 'localhost';
$db   = 'saat_dunyasi';     // Veritabanı adını buraya yaz
$user = 'kullanici_adi';    // cPanel'den oluşturduğun kullanıcı adı
$pass = 'parolan';          // Kullanıcının şifresi

$conn = new mysqli($host, $user, $pass, $db);
if ($conn->connect_error) {
    die("Bağlantı hatası: " . $conn->connect_error);
}

// Form gönderildiyse
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name     = $conn->real_escape_string($_POST['name']);
    $email    = $conn->real_escape_string($_POST['email']);
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);

    $check = $conn->query("SELECT id FROM users WHERE email='$email'");
    if ($check->num_rows > 0) {
        $error = "Bu e-posta adresi zaten kayıtlı.";
    } else {
        $conn->query("INSERT INTO users (name, email, password) VALUES ('$name', '$email', '$password')");
        header("Location: login.php");
        exit;
    }
}
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <title>Kayıt Ol - Saat Dünyası</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header>
        <div class="container">
            <h1>Saat Dünyası</h1>
            <nav>
                <a href="index.php">Anasayfa</a>
                <a href="products.php">Ürünler</a>
                <a href="cart.php">Sepetim</a>
                <a href="login.php">Giriş</a>
                <a href="register.php">Kayıt Ol</a>
            </nav>
        </div>
    </header>

    <section class="container">
        <h2>Kayıt Ol</h2>
        <?php if (isset($error)) echo "<p style='color:red;'>$error</p>"; ?>
        <form action="register.php" method="post" class="form-box">
            <label for="name">Ad Soyad:</label>
            <input type="text" name="name" required>

            <label for="email">E-posta:</label>
            <input type="email" name="email" required>

            <label for="password">Şifre:</label>
            <input type="password" name="password" required>

            <button type="submit" class="btn">Kayıt Ol</button>
        </form>
        <p>Zaten hesabınız var mı? <a href="login.php">Giriş yapın</a></p>
    </section>

    <footer>
        <div class="container">
            <p>&copy; 2025 Saat Dünyası | Tüm hakları saklıdır.</p>
        </div>
    </footer>
</body>
</html>

