<?php
// Ürün ID'si alınıyor
$id = isset($_GET['id']) ? $_GET['id'] : 1;

// Sahte ürün verisi (ileride veritabanına bağlayabiliriz)
$products = [
    1 => [
        'name' => 'Casio G-Shock',
        'price' => '₺1.500',
        'description' => 'Casio G-Shock, darbelere dayanıklı ve sportif tasarımı ile dikkat çeker.',
        'image' => 'assets/watch1.jpg'
    ],
    2 => [
        'name' => 'Rolex Submariner',
        'price' => '₺35.000',
        'description' => 'Rolex Submariner, su geçirmez yapısı ve zarafetiyle lüks saat kategorisindedir.',
        'image' => 'assets/watch2.jpg'
    ],
    3 => [
        'name' => 'Fossil Chronograph',
        'price' => '₺3.200',
        'description' => 'Fossil Chronograph, klasik ve modern çizgileri bir arada sunar.',
        'image' => 'assets/watch3.jpg'
    ]
];

$product = $products[$id];
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <title><?php echo $product['name']; ?> - Saat Dünyası</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header>
        <div class="container">
            <h1>Saat Dünyası</h1>
            <nav>
                <a href="index.php">Anasayfa</a>
                <a href="products.php">Ürünler</a>
                <a href="cart.php">Sepetim</a>
                <a href="login.php">Giriş</a>
                <a href="register.php">Kayıt Ol</a>
            </nav>
        </div>
    </header>

    <section class="container">
        <div class="product-detail">
            <img src="<?php echo $product['image']; ?>" alt="<?php echo $product['name']; ?>" class="detail-img">
            <div class="detail-info">
                <h2><?php echo $product['name']; ?></h2>
                <p class="price"><?php echo $product['price']; ?></p>
                <p><?php echo $product['description']; ?></p>
                <a href="cart.php?add=<?php echo $id; ?>" class="btn">Sepete Ekle</a>
            </div>
        </div>
    </section>

    <footer>
        <div class="container">
            <p>&copy; 2025 Saat Dünyası | Tüm hakları saklıdır.</p>
        </div>
    </footer>
</body>
</html>
