<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <title>Giriş Yap - Saat Dünyası</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header>
        <div class="container">
            <h1>Saat Dünyası</h1>
            <nav>
                <a href="index.php">Anasayfa</a>
                <a href="products.php">Ürünler</a>
                <a href="cart.php">Sepetim</a>
                <a href="login.php">Giriş</a>
                <a href="register.php">Kayıt Ol</a>
            </nav>
        </div>
    </header>

    <section class="container">
        <h2>Giriş Yap</h2>
        <form action="login.php" method="post" class="form-box">
            <label for="email">E-posta:</label>
            <input type="email" name="email" required>

            <label for="password">Şifre:</label>
            <input type="password" name="password" required>

            <button type="submit" class="btn">Giriş Yap</button>
        </form>
        <p>Hesabınız yok mu? <a href="register.php">Kayıt olun</a></p>
    </section>

    <footer>
        <div class="container">
            <p>&copy; 2025 Saat Dünyası | Tüm hakları saklıdır.</p>
        </div>
    </footer>
</body>
</html>
