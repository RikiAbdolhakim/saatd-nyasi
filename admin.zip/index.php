<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <title>Saat Dünyası - Anasayfa</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header>
        <div class="container">
            <h1>Saat Dünyası</h1>
            <nav>
                <a href="index.php">Anasayfa</a>
                <a href="products.php">Ürünler</a>
                <a href="cart.php">Sepetim</a>
                <a href="login.php">Giriş</a>
                <a href="register.php">Kayıt Ol</a>
            </nav>
        </div>
    </header>

    <section class="hero">
        <div class="container">
            <h2>Şıklığın Zamanla Buluştuğu Nokta</h2>
            <p>En iyi saat markaları, en uygun fiyatlarla!</p>
        </div>
    </section>

    <section class="products container">
        <h2>En Çok Satan Saatler</h2>
        <div class="product-grid">
            <div class="product-card">
                <img src="assets/watch1.jpg" alt="Casio G-Shock">
                <h3>Casio G-Shock</h3>
                <p>Dayanıklı ve sportif bir saat.</p>
                <a href="product_detail.php?id=1" class="btn">İncele</a>
            </div>
            <div class="product-card">
                <img src="assets/watch2.jpg" alt="Rolex Submariner">
                <h3>Rolex Submariner</h3>
                <p>Lüks ve zarif tasarım.</p>
                <a href="product_detail.php?id=2" class="btn">İncele</a>
